#!/usr/bin/python
''' DON'T TOUCH THESE FIRST LINES! '''
''' ============================== '''
from myo import *

myo = Myo(sys.argv[1] if len(sys.argv) >= 2 else None) 
''' ============================== '''

# Edit here:
def onPoseEdge(pose, edge):
	print("onPoseEdge: "+pose+", "+edge)
# Stop editting

myo.onPoseEdge = onPoseEdge     # Remember to uncomment this line!

''' DON'T TOUCH BELOW THIS LINE! '''
''' ============================ '''
myo.connect()
while True:
	myo.run()
	myo.tick()
