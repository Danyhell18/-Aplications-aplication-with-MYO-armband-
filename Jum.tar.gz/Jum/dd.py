print 'you preseed %s' % key
