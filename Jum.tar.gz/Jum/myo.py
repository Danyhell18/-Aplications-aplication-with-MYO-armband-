from expyriment import design, control, stimuli, io, misc
# Create and initialize an experiment
exp = design.Experiment("Simon Task")
control.initialize(exp)
# Create the design
for task in ["left=green", "left=red"]:
	b = design.Block()
	b.set_factor("Task", task)
	for pos in [["left",-300], ["right",300]]:
	  for col in [["red",misc.constants.C_RED],
		["green",misc.constants.C_GREEN]]:
		t = design.Trial()
		t.set_factor("Position", pos[0])
		t.set_factor("Colour", col[0])
		rect = stimuli.Rectangle(size=[50,50], position=[pos[1], 0],
		colour=col[1])
		t.add_stimulus(rect)
		b.add_trial(t, copies=32)
	b.shuffle_trials()
	exp.add_block(b)
exp.add_bws_factor("TaskOrder", ["left=green first" ,"left=red first"])

# Create and preload global stimuli
blankscreen = stimuli.BlankScreen()
blankscreen.preload()
fixcross = stimuli.FixCross()
fixcross.preload()

# Start the experiment
control.start()
exp.data_variable_names = ["Position", "Key", "RT"]
if exp.get_permuted_bws_factor_condition("TaskOrder") == "left=red first":
	exp.swap_blocks(0,1)
# Run trials
for block in exp.blocks:
	stimuli.TextScreen("Instructions", block.get_factor("Task")).present()
	exp.keyboard.wait()
	blankscreen.present()
	for trial in block.trials:
		exp.clock.wait(3000 - trial.preload_stimuli())
		fixcross.present()
		exp.clock.wait(500)
		trial.stimuli[0].present() # Target stimulus
		key, rt = exp.keyboard.wait([misc.constants.K_LEFT,
		misc.constants.K_RIGHT])
		blankscreen.present()
		exp.data.add([trial.get_factor("Position"), key, rt])
		trial.unload_stimuli()
# End the experiment
control.end(goodbye_text="Thank you for participating!")
