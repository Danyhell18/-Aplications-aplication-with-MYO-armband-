import serial
import sys
import sumo
import time

cnt = sumo.SumoController('MyCtrl')
cnt.connect()

car=serial.Serial('/dev/ttyACM2',9600)
print("hh")
while True:
	medida=car.readline()
	print (car.readline())
	if (car.readline()>=170 and car.readline() <=190):
		cnt.move(10)
		cnt.move(10,10) # grio der speed = [-100:100],turn_speed = [-100:100]
	else:
		cnt.move(-30,0) # grio der speed = [-100:100],turn_speed = [-100:100]
		
