    from msvcrt import getch
     
    c = getch()
    if c == '\r':
        print "presionaste enter"
    elif c == '\x1b':
        print "presionaste esc"
    else:
        print "No se que presionaste"
