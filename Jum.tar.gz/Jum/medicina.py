import serial

car=serial.Serial('/dev/ttyACM3',9600,)
while True:
	print(car.readline())
