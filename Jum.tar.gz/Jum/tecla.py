from tkinter import *

def main():
  root = Tk()

  def callback(evento):
    print("La tecla es", evento.keycode) # Línea clave del programa

  frame = Frame(root, width=100, height=100)
  frame.bind("<KeyPress>", callback)
  frame.pack()

  root.mainloop()
