import serial
import sys
import sumo
import time

cnt = sumo.SumoController('MyCtrl')
cnt.connect()

car=serial.Serial('/dev/ttyACM0',9600,)
while True:
	medida=float(car.readline())
	print (car.readline())
	if (medida >15.0):
		cnt.move(30,-10) # grio der speed = [-100:100],turn_speed = [-100:100]
	if (medida <15.0):
		cnt.move(15,0) # grio der speed = [-100:100],turn_speed = [-100:100]
		
