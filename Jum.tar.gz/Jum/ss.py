import sumo
import time

cnt = sumo.SumoController('MyCtrl')
cnt.connect()
cnt.move(10)
time.sleep(3)
#cnt.move(0)
cnt.move(10, -5) # speed = [-100:100],turn_speed = [-100:100]
#cnt.action(param)     #      ; param = [0:9]
#cnt.jump(param)        #     ; param = [0:1]
#cnt.posture(param)      #    ; param = [0:2]
time.sleep(3)
