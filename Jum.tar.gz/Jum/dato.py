cadena = raw_input("Introduce una cadena de texto: ")
print "La cadena que ingreso es:\n",cadena

#if (cadena=="den"):
# print"holi"
#else:
# print "no holi"

