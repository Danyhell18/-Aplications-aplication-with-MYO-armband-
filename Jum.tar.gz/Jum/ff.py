import sys
import sumo
import time

cnt = sumo.SumoController('MyCtrl')
cnt.connect()

 

x='si'
den=0
 

while x=='si':

    tecla = sys.stdin.read(1)

    if tecla=='a':
        print 'izquierda'
        cnt.move(10)
	cnt.move(10,-10)	
    if tecla=='d':
        print 'derecha'
        cnt.move(10)
	cnt.move(10,10) # grio der speed = [-100:100],turn_speed = [-100:100]
    if tecla=='w':
	print'adelante'
        cnt.move(40)
        cnt.move(40,0) # grio der speed = [-100:100],turn_speed = [-100:100]
    if tecla=='x':
	print 'retrocede'
        cnt.move(-40)
       
    if tecla=='q':
	print 'cambioPos'
	den=den+1
	if den==3:
		den=1
	cnt.posture(den-1)
    if tecla=='e':
	print 'Salto'
	#cnt.move(10)
	cnt.jump(1)
	cnt.jump(0)	
    if tecla != 's':

        print 'Has presionado ', tecla

    else:

        x='no'

        print 'Se rompe el bucle'
